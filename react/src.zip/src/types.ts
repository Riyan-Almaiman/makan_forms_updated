export interface Calculation {
  calculationId?: number;
  layer: string;
  remark: string;
  valuePerHour: number;
  valuePer8Hours: number;
  targetType: string;
  product: string;
}

export interface DailyTarget {
  targetId?: number;
  hoursWorked: number;
  productivity: number;
  targetType: string | null;
  remarks: string | null;
  layers: string | null;
  formId: number;
  expectedProductivity: number | null
  form?: Form;
}

export interface Form {
  formId?: number;
  comment: string | null;
  product: string | null;
  submissionDate: string;
  productivityDate: string;
  employeeName: string | null;
  supervisorTaqniaID: number | null;
  dailyTargets?: DailyTarget[];
  approvals?: Approval[];
  taqniaID: number;
  user?: User;
}

export interface Approval {
  stepOrder: number;

  approvalId?: number;
  supervisorTaqniaID: number | null;
  supervisorComment: string | null;
  state: FormState
  formId: number;
  form?: Form;
}

export interface User {
  taqniaID: number;
  name: string | null;
  product: string | null;
  layer: string | null;
  username: string | null;
  password: string | null;
  role: string | null;
  employeeType: string | null;
  supervisorTaqniaID: number | null;
}

export const  Layer = {
  Agriculture: 'Agriculture',
  'Culture and Recreation': 'Culture and Recreation',
  Roads: 'Roads',
  'Utility Network': 'Utility Network',
  Hydrography: 'Hydrography',
  Physiography: 'Physiography',
  Buildings: 'Buildings/Structure	',
  
  // Add more layers as needed
};

export const Remark = {
  Empty: 'Empty',
  Easy: 'Easy',
  Medium: 'Medium',
  Dense: 'Dense',
  'Mountain/Terrace Dense': 'Mountain/Terrace Dense',
  // Add more remarks as needed
};

export const TargetType = {
  SQKM: 'SQKM',
  Sheets: 'Sheets',
  KM: 'KM',
  // Add more target types as needed
};

export const Product = {
  TDS7: 'TDS7',
  Cartography: 'Cartography',
  UVMAP: 'UVMAP',
  // Add more products as needed
};
export type FormState = "New" | "pending" | "approved" | "rejected" | "unknown" | null;

export function calculateExpectedProductivityForTarget(target: DailyTarget, calculations: Calculation[]): number {
  console.log(calculations);
  const matchingCalculation = calculations.find(
    calc =>
      calc.layer.toLowerCase() === (target.layers?.toLowerCase() ?? '') &&
      calc.remark.toLowerCase() === (target.remarks?.toLowerCase() ?? '') &&
      calc.targetType.toLowerCase() === (target.targetType?.toLowerCase() ?? '')
  );

  if (!matchingCalculation) {
    return 0;
  }

  // Calculate expected productivity based on hours worked
  const expectedProductivity = (target.hoursWorked / 8) * matchingCalculation.valuePer8Hours;

  return expectedProductivity;
}

export function calculateAverageExpectedProductivity(targets: DailyTarget[], calculations: Calculation[]): number {
  if (targets.length === 0) {
    return 0;
  }
  let totalproductivity = 0;
  let totalExpectedProductivity = 0;

  targets.forEach((target) => {
    const prod = target.productivity as number;
    totalproductivity += prod as number;
  });

  targets.forEach((target) => {
    totalExpectedProductivity += calculateExpectedProductivityForTarget(target, calculations);
  });

  console.log(totalproductivity, totalExpectedProductivity);
  const result = totalproductivity / totalExpectedProductivity;
  return result * 100;
}