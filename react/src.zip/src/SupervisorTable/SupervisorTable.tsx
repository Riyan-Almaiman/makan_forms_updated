import React, { useEffect, useState } from "react";
import { Calculation, Form, User, Approval } from "../types";
import ModalComponent from "./ModalComponent";
import { DateTime } from "luxon";
import { formService } from "../services/formService";
import { approvalService } from "../services/approvalService";

interface Props {
  user: User;
  calculations: Calculation[];
}

const SupervisorTable: React.FC<Props> = ({ user, calculations }) => {
  const [forms, setForms] = useState<Form[]>([]);
  const [selectedForm, setSelectedForm] = useState<Form | null>(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState("All");
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      let fetchedForms;
      if (selectedDate) {
        fetchedForms = await formService.getSupervisorFormsByDate(user.taqniaID, selectedDate);
      } else {
        fetchedForms = await formService.getSupervisorPendingForms(user.taqniaID);
      }
      setForms(fetchedForms);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedDate, user.taqniaID]);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedDate(e.target.value || null);
  };

  const handleEmployeeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedEmployee(e.target.value);
  };

  const openModal = (form: Form) => {
    setSelectedForm(form);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setSelectedForm(null);
    setModalIsOpen(false);
  };

  const handleApprove = async (supervisorComment: string) => {
    if (selectedForm && selectedForm.approvals && selectedForm.approvals.length > 0) {
      const approval = selectedForm.approvals[0];
      const updatedApproval: Approval = {
        ...approval,
        state: "approved",
        supervisorComment: supervisorComment
      };
      try {
        if(!approval.approvalId) return; 
        await approvalService.updateApproval(approval.approvalId, updatedApproval);
        await fetchData();
        closeModal();
      } catch (error) {
        console.error("Error approving form:", error);
      }
    }
  };

  const handleReject = async (supervisorComment: string) => {
    if (selectedForm && selectedForm.approvals && selectedForm.approvals.length > 0) {
      const approval = selectedForm.approvals[0];
      const updatedApproval: Approval = {
        ...approval,
        state: "rejected",
        supervisorComment: supervisorComment
      };
      if(!approval.approvalId) return; 
      try {
        await approvalService.updateApproval(approval.approvalId, updatedApproval);
        await fetchData();
        closeModal();
      } catch (error) {
        console.error("Error rejecting form:", error);
      }
    }
  };

  const formatDateTime = (dateTimeString: string): string => {
    const dt = DateTime.fromISO(dateTimeString);
    return dt.toFormat("dd/MM/yyyy HH:mm:ss");
  };

  const filteredForms = forms.filter((form) => {
    if (selectedEmployee !== "All" && form.employeeName !== selectedEmployee) return false;
    return true;
  });

  const uniqueEmployeeNames = ["All", ...new Set(forms.map((form) => form.employeeName).filter(Boolean))];

  const getApprovalButton = (form: Form) => {
    const approval = form.approvals && form.approvals[0];
    if (!approval) return null;

    const buttonClasses = "btn ml-4 text-white btn-xs ";
    let buttonText, buttonColor;

    switch(approval.state?.toLowerCase()) {
      case 'pending':
        buttonText = "Pending";
        buttonColor = "bg-orange-500 hover:bg-orange-600 border-orange-500";
        break;
      case 'approved':
        buttonText = "Approved";
        buttonColor = "bg-green-500 hover:bg-green-600 border-green-500";
        break;
      case 'rejected':
        buttonText = "Rejected";
        buttonColor = "bg-red-500 hover:bg-red-600 border-red-500";
        break;
      default:
        return null;
    }

    return (
      <button
        className={buttonClasses + buttonColor}
        onClick={() => openModal(form)}
      >
        {buttonText}
      </button>
    );
  };

  return (
    <div className="flex flex-col h-full p-4">
      <div className="mb-4">
        <label htmlFor="date" className="block text-gray-700 font-bold mb-2">
          Filter by Date (leave empty for pending forms):
        </label>
        <input
          type="date"
          id="date"
          value={selectedDate || ''}
          onChange={handleDateChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      <div className="mb-4">
        <label htmlFor="employee" className="block text-gray-700 font-bold mb-2">
          Filter by Editor:
        </label>
        <select
          id="employee"
          value={selectedEmployee}
          onChange={handleEmployeeChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {uniqueEmployeeNames.map((name) => (
            name && <option key={name} value={name}>{name}</option>
          ))}
        </select>
      </div>
      <div className="flex-grow overflow-hidden">
        <div className="overflow-y-auto h-full">
          <table className="min-w-full table table-zebra bg-gray-200 rounded-lg">
            <thead>
              <tr>
                <th>Employee Name</th>
                <th>Product</th>
                <th>Layers</th>
                <th>Productivity Date</th>
                <th>Form Submission Date</th>
                <th>Status</th>
              </tr>
            </thead>
            {loading ? (
              <tbody>
                <tr>
                  <td colSpan={6} className="text-center font-bold text-lg">Loading data...</td>
                </tr>
              </tbody>
            ) : (
              <tbody>
                {filteredForms.map((form) => (
                  <tr className="text-balance" key={form.formId}>
                    <td>{form.employeeName}</td>
                    <td>{form.product || "No Product"}</td>
                    <td>{form.dailyTargets?.map((dt) => dt.layers).join(", ")}</td>
                    <td>{DateTime.fromISO(form.productivityDate).toFormat("dd/MM/yyyy")}</td>
                    <td>{formatDateTime(form.submissionDate)}</td>
                    <td>{getApprovalButton(form)}</td>
                  </tr>
                ))}
              </tbody>
            )}
          </table>
        </div>
      </div>

      <ModalComponent
        calculations={calculations}
        form={selectedForm}
        isOpen={modalIsOpen}
        onClose={closeModal}
        onApprove={handleApprove}
        onReject={handleReject}
      />
    </div>
  );
};

export default SupervisorTable;