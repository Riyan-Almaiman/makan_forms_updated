import { useState } from "react";
import { Form, Calculation, calculateExpectedProductivityForTarget } from "../types";
import { DateTime } from "luxon";

interface Props {
  form: Form | null;
  isOpen: boolean;
  onClose: () => void;
  calculations: Calculation[] | undefined;
  onApprove: (supervisorComment: string) => void;
  onReject: (supervisorComment: string) => void;
}

const ModalComponent = ({
  form,
  isOpen,
  onClose,
  calculations,
  onApprove,
  onReject,
}: Props) => {
  const [supervisorComment, setSupervisorComment] = useState("");

  const formatDateTime = (dateTimeString: string): string => {
    return DateTime.fromISO(dateTimeString).toFormat("dd/MM/yyyy HH:mm:ss");
  };

  const handleApprove = () => {
    onApprove(supervisorComment);
    setSupervisorComment("");
  };

  const handleReject = () => {
    onReject(supervisorComment);
    setSupervisorComment("");
  };

  if (!form) return null;

  //const totalProductivityPercentage = calculateAverageExpectedProductivity(form.dailyTargets || [], calculations || []);

  return (
    <dialog id="form_modal" className={`modal ${isOpen ? 'modal-open' : ''}`}>
      <div className="modal-box max-w-4xl bg-white rounded-lg shadow-xl">
        <h3 className="font-bold text-2xl mb-4 text-[#196A58]">Form Details</h3>
        <div className="grid grid-cols-2 gap-4 mb-6 bg-gray-50 p-4 rounded-lg">
          <div>
            <p><span className="font-semibold">Employee Name:</span> {form.employeeName}</p>
            <p><span className="font-semibold">Product:</span> {form.product || "No Product"}</p>
            <p><span className="font-semibold">Productivity Date:</span> {DateTime.fromISO(form.productivityDate).toFormat("dd/MM/yyyy")}</p>
          </div>
          <div>
            <p><span className="font-semibold">Form Submission:</span> {formatDateTime(form.submissionDate)}</p>
            {/* <p><span className="font-semibold">Total Productivity:</span> {totalProductivityPercentage.toFixed(2)}%</p> */}
          </div>
        </div>

        <div className="overflow-x-auto mb-6">
          <table className="table w-full">
            <thead>
              <tr className="bg-gray-100">
                <th>Layer</th>
                <th>Target Type</th>
                <th>Hours Worked</th>
                <th>Actual Productivity</th>
                <th>Expected Productivity</th>
                <th>Productivity %</th>
              </tr>
            </thead>
            <tbody>
              {form.dailyTargets?.map((dt, index) => {
                const expectedProductivity = calculateExpectedProductivityForTarget(dt, calculations || []);
                const productivityPercentage = (dt.productivity / expectedProductivity) * 100;

                return (
                  <tr key={index} className="hover:bg-gray-50">
                    <td>{dt.layers}</td>
                    <td>{dt.targetType}</td>
                    <td>{dt.hoursWorked}</td>
                    <td>{dt.productivity.toFixed(2)}</td>
                    <td>{expectedProductivity.toFixed(2)}</td>
                    <td>{productivityPercentage.toFixed(2)}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <p className="font-semibold">Editor Comment:</p>
          <p className="mt-2">{form.comment || "No Comment"}</p>
        </div>

        <div className="form-control mb-6">
          <label className="label">
            <span className="label-text font-semibold">Supervisor Comment:</span>
          </label>
          <textarea
            value={supervisorComment}
            onChange={(e) => setSupervisorComment(e.target.value)}
            placeholder="Add your comment here"
            className="textarea textarea-bordered h-24"
          ></textarea>
        </div>

        <div className="modal-action">
          <button onClick={handleApprove} className="btn btn-success">Approve</button>
          <button onClick={handleReject} className="btn btn-error">Reject</button>
          <button onClick={onClose} className="btn">Close</button>
        </div>
      </div>
    </dialog>
  );
};

export default ModalComponent;