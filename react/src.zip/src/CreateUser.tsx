import React, { useState, useEffect } from "react";
import { User } from "./types";
import { userService } from "./services/userService";
import SearchSelect from "./SearchSelect";

const CreateUser: React.FC = () => {
  const [user, setUser] = useState<User>({
    name: "",
    product: "",
    layer: "",
    username: "",
    password: "",
    taqniaID: 0,
    role: "",
    employeeType: "",
    supervisorTaqniaID: null,
  });

  const [isEdit, setIsEdit] = useState(false);
  const [supervisors, setSupervisors] = useState<User[]>([]);

  useEffect(() => {
    fetchSupervisors();
  }, []);

  const fetchSupervisors = async () => {
    try {
      const users = await userService.getAllUsers();
      const supervisorList = users.filter((user) => user.role === "supervisor");
      setSupervisors(supervisorList);
    } catch (error) {
      console.error("Error fetching supervisors:", error);
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setUser((prevUser) => {
      const updatedUser = { ...prevUser };
  
      switch (name) {
        case "supervisorTaqniaID":
          updatedUser.supervisorTaqniaID = value ? parseInt(value) : null;
          break;
        case "name":
          updatedUser.name = value;
          const nameParts = value.trim().split(" ");
          if (nameParts.length > 1) {
            updatedUser.username = (nameParts[0][0] + nameParts[nameParts.length - 1]).toLowerCase();
          }
          break;
        case "taqniaID":
          updatedUser.taqniaID = parseInt(value);
          updatedUser.password = value;
          break;
        case "username":
        case "password":
        case "product":
        case "layer":
        case "role":
        case "employeeType":
          updatedUser[name] = value;
          break;
        default:
          console.warn(`Unhandled input field: ${name}`);
      }
  
      return updatedUser;
    });
  };

  const handleCancel = () => {
    setUser({
      name: "",
      product: "",
      layer: "",
      username: "",
      password: "",
      taqniaID: 0,
      role: "",
      employeeType: "",
      supervisorTaqniaID: null,
    });
    setIsEdit(false);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      if (isEdit && user.taqniaID) {
        await userService.updateUser(user.taqniaID, user);
      } else {
        await userService.createUser(user);
      }
      handleCancel();
      console.log("User created/edited successfully");
    } catch (error) {
      console.error("Error creating/editing user:", error);
      alert("Error creating/editing user: " + error);
    }
  };

  const handleSelect = async (selected: { value: string; label: string }) => {
    try {
      const selectedUser = await userService.getUserByTaqniaId(parseInt(selected.value));
      if (selectedUser) {
        setUser(selectedUser);
        setIsEdit(true);
      }
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  };

  const fetchUserOptions = async () => {
    try {
      const users = await userService.getAllUsers();
      return users.map((user) => ({
        value: user.taqniaID.toString(),
        label: user.name || '',
      }));
    } catch (error) {
      console.error("Error fetching user options:", error);
      return [];
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      <form onSubmit={handleSubmit} className="rounded-lg px-10 pt-12 pb-10">
        <h4 className="mb-10 justify-center font-bold text-2xl flex">
          {isEdit ? "Edit User" : "Create User"}
        </h4>
        <SearchSelect
          fetchOptions={fetchUserOptions}
          onSelect={handleSelect}
          placeholder="Select user to edit..."
        />
        <div className="grid grid-cols-2 gap-6 mt-6">
          <div>
            <label htmlFor="name" className="block text-gray-700 text-sm font-bold mb-2">
              Name
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={user.name || ''}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label htmlFor="taqniaID" className="block text-gray-700 text-sm font-bold mb-2">
              Taqnia ID
            </label>
            <input
              type="number"
              id="taqniaID"
              name="taqniaID"
              value={user.taqniaID}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label htmlFor="username" className="block text-gray-700 text-sm font-bold mb-2">
              Username
            </label>
            <input
              type="text"
              id="username"
              name="username"
              value={user.username || ''}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-gray-700 text-sm font-bold mb-2">
              Password
            </label>
            <input
              type="text"
              id="password"
              name="password"
              value={user.password || ''}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label htmlFor="role" className="block text-gray-700 text-sm font-bold mb-2">
              Role
            </label>
            <select
              id="role"
              name="role"
              value={user.role || ''}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Select Role</option>
              <option value="editor">Editor</option>
              <option value="supervisor">Supervisor</option>
            </select>
          </div>
          <div>
            <label htmlFor="supervisorTaqniaID" className="block text-gray-700 text-sm font-bold mb-2">
              Supervisor
            </label>
            <select
              id="supervisorTaqniaID"
              name="supervisorTaqniaID"
              value={user.supervisorTaqniaID?.toString() || ''}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">No Supervisor</option>
              {supervisors.map((supervisor) => (
                <option key={supervisor.taqniaID} value={supervisor.taqniaID.toString()}>
                  {supervisor.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-8 flex justify-center space-x-4">
          <button
            type="submit"
            className="bg-[#196A58] hover:bg-green-800 text-white font-bold py-2 px-6 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {isEdit ? "Edit User" : "Create User"}
          </button>
          {isEdit && (
            <button
              type="button"
              onClick={handleCancel}
              className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              Cancel
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default CreateUser;