import React, { useState } from 'react';

interface LoginProps {
  onLogin: (credentials: { username: string; password: string }) => void;
}

function Login({ onLogin }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    const credentials = { username, password };
    try {
      setError('')
      await onLogin(credentials);
    } catch (err) {
      setError('Login failed. Please check your username and password.');
    }
  };

  return (
    <div
      style={{ backgroundImage: `url(makanBackgroundDark.png)` }}
      className="w-full max-w-md bg-white px-6 pt-10 pb-8 shadow-xl ring-1 ring-gray-900/5 sm:rounded-xl sm:px-10"
    >
      <div className="w-full">
        <div className="text-center">
          <h1 className="text-3xl font-semibold text-gray-100">Sign in</h1>
          <p className="mt-2 text-gray-200">Sign in below to access your account</p>
        </div>
        {error && (
          <div className="mt-4 text-red-600">
            {error}
          </div>
        )}
        <div className="mt-5">
          <form onSubmit={handleSubmit}>
            <div className="mt-6">
              <input
                type="text"
                name="username"
                id="username"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-2 rounded border-b-2 border-gray-300 py-1 focus:border-gray-500 focus:outline-none"
                autoComplete="off"
              />
            </div>
            <div className="mt-6">
              <input
                type="password"
                name="password"
                id="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-2 border-b-2 rounded border-gray-300 py-1 focus:border-gray-500 focus:outline-none"
              />
            </div>
            <div className="my-6">
              <button
                type="submit"
                className="w-full rounded-md bg-[#196A58] px-3 py-4 text-white focus:bg-gray-600 focus:outline-none"
              >
                Sign in
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
