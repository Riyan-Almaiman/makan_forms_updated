import * as React from 'react';
import { BarChart } from '@mui/x-charts/BarChart';
import { ProductivityData } from "../services/dashboardService";

interface ProductivityChartProps {
  productivityData: ProductivityData | null;
}

export default function ProductivityChart({ productivityData }: ProductivityChartProps) {
  const [selectedProduct, setSelectedProduct] = React.useState<"tds7" | "uvmap" | "cartography">("tds7");
  const [selectedLayer, setSelectedLayer] = React.useState<string | null>(null);

  if (!productivityData) {
    return <div>Loading...</div>;
  }

  const layers = productivityData.products[selectedProduct].layers;
  const layerNames = Object.keys(layers);

  const percentages = layerNames.map(layer => {
    const expected = layers[layer].expectedProductivity;
    const actual = layers[layer].actualProductivity;
    return expected > 0 ? (actual / expected) * 100 : 0;
  });

  const handleProductChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedProduct(e.target.value as "tds7" | "uvmap" | "cartography");
    setSelectedLayer(null);
  };

  const handleLayerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedLayer(e.target.value);
  };

  let chartData;
  let xAxisData;
  let chartColors;

  if (selectedLayer) {
    chartData = [
      { data: [layers[selectedLayer].expectedProductivity], label: 'Expected Productivity' },
      { data: [layers[selectedLayer].actualProductivity], label: 'Actual Productivity' },
    ];
    xAxisData = [selectedLayer];
    chartColors = ['#a1c2c3', '#196A58']; // Dark green for expected, orange for actual
  } else {
    chartData = [{ data: percentages, label: 'Actual/Expected %' }];
    xAxisData = layerNames;
    chartColors = ['#196A58']; // Dark green for percentage bars
  }

  const isAllZero = chartData.every(series => series.data.every(value => value === 0));

  return (
    <div className="w-full max-w-full overflow-x-auto">
      <div className="mb-4 flex space-x-4">
        
        <div>
          <label htmlFor="product-select" className="mr-2">Select Product:</label>
          <select id="product-select" value={selectedProduct} onChange={handleProductChange}  className="px-2 py-1 border border-gray-300 rounded-md text-sm w-32"
          >
            <option value="tds7">TDS7</option>
            <option value="uvmap">UVMap</option>
            <option value="cartography">Cartography</option>
          </select>
        </div>
        <div>
          <label htmlFor="layer-select" className="mr-2">Select Layer:</label>
          <select id="layer-select" value={selectedLayer || ''} onChange={handleLayerChange}   className="px-2 py-1 border border-gray-300 rounded-md text-sm w-32"
          >
            <option value="">All Layers</option>
            {layerNames.map(layer => (
              <option key={layer} value={layer}>{layer}</option>
            ))}
          </select>
        </div>
      </div>
      {isAllZero ? (
        <div className="w-[600px] h-[400px] flex items-center justify-center border border-[#196A58] rounded-md">
          <p className="text-2xl font-bold text-[#196A58]">No data</p>
        </div>
      ) : (
<BarChart
 barLabel={(item) => {
  if (item.value === null) return '';
  const value = Math.round(item.value).toString();
  return selectedLayer ? value : value + '%';
}}
  series={chartData}
  width={600}
  height={400}
  colors={chartColors}
  xAxis={[{ 
    data: xAxisData, 
    scaleType: 'band',
    tickLabelStyle: {
      angle: 25,
      textAnchor: 'start',
      fontSize: 10
    }
  }]}
  yAxis={[{
    label: selectedLayer ? 'Productivity' : 'Actual/Expected %',
    max: selectedLayer ? undefined : 100,
  }]}
  margin={{ top: 40, bottom: 90, left: 60, right: 40 }}
  slotProps={{
    legend: {
      direction: 'row',
      position: { vertical: 'top', horizontal: 'middle' },
      padding: 5,
    },
    barLabel: {
      style: {
        fill: 'white',
        fontSize: 12,
        fontWeight: 'bold',
      },
    },
  }}
/>
      )}
    </div>
  );
}