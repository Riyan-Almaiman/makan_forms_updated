import React, { useState, useEffect } from "react";
import { dashboardService, ProductivityData } from "../services/dashboardService";
import ProductivityChart from "./ProductivityChart";
import StatsComponent from "./StatsComponent";
import SupervisorStats from "./SupervisorStats";



const DashBoard = () => {
  const [date, setDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [data, setData] = useState<ProductivityData | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await dashboardService.GetProductivityDashboard(date);
        console.log(result)
        setData(result);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      }
    };

    fetchData();
  }, [date]);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDate(e.target.value);
  };

  return (
    <div className="container mx-auto p-6 bg-gray-100">
      <div className="flex justify-center mb-6">
        <input
          required
          type="date"
          id="date"
          value={date}
          onChange={handleDateChange}
          className="px-4 py-2 border border-gray-300 rounded-md"
        />
      </div>
      
      {/* Stats component */}
      <StatsComponent Stats={data} />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg  font-bold text-[#196A58]  mb-2">Targets</h3>
          <ProductivityChart productivityData={data} />
        </div>
     
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg  font-bold text-[#196A58]  mb-2">Supervisor Stats</h3>
          <SupervisorStats SupervisorStats={data?.supervisorStats } />
        </div>
        </div>
    </div>
  );
};

export default DashBoard;