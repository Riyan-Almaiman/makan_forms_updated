import React from 'react';
import {  ProductivityData } from "../services/dashboardService";



function calculateStats(data: ProductivityData): {
    totalProductivityPercentage: number;
    totalApprovedForms: number;
    totalRemainingForms: number;
    totalHoursWorked: number;
    averageHoursWorked: number;
} {
    let totalExpectedProductivity = 0;
    let totalActualProductivity = 0;
    let totalApprovedForms = 0;

    // Calculate totals across all products and layers
    Object.values(data.products).forEach(product => {
        Object.values(product.layers).forEach(layer => {
            totalExpectedProductivity += layer.expectedProductivity;
            totalActualProductivity += layer.actualProductivity;
            totalApprovedForms += layer.approvedForms;
        });
    });

    // Calculate total productivity percentage
    const totalProductivityPercentage = totalExpectedProductivity > 0
        ? (totalActualProductivity / totalExpectedProductivity) * 100
        : 0;

    // Calculate total remaining forms
    const totalRemainingForms = data.forms.pending + data.forms.rejected;

    // Get total hours worked and average hours worked from editors data
    const { totalHoursWorked, averageHoursWorked } = data.editors;

    return {
        totalProductivityPercentage: Number(totalProductivityPercentage.toFixed(2)),
        totalApprovedForms,
        totalRemainingForms,
        totalHoursWorked,
        averageHoursWorked: Number(averageHoursWorked.toFixed(2))
    };
}
interface props {

    Stats: ProductivityData | null
}
const StatsComponent: React.FC<props> = ({Stats}) => {

    const stats = Stats ? calculateStats(Stats) : null;

  return (
    <div className="stats shadow w-full mb-6">
      <div className="stat">
        <div className="stat-figure text-[#196A58]">
        <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            className="inline-block h-8 w-8 stroke-current">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M19 3V7M17 5H21M19 17V21M17 19H21M10 5L8.53001 8.72721C8.3421 9.20367 8.24814 9.4419 8.10427 9.64278C7.97675 9.82084 7.82084 9.97675 7.64278 10.1043C7.4419 10.2481 7.20367 10.3421 6.72721 10.53L3 12L6.72721 13.47C7.20367 13.6579 7.4419 13.7519 7.64278 13.8957C7.82084 14.0233 7.97675 14.1792 8.10427 14.3572C8.24814 14.5581 8.3421 14.7963 8.53001 15.2728L10 19L11.47 15.2728C11.6579 14.7963 11.7519 14.5581 11.8957 14.3572C12.0233 14.1792 12.1792 14.0233 12.3572 13.8957C12.5581 13.7519 12.7963 13.6579 13.2728 13.47L17 12L13.2728 10.53C12.7963 10.3421 12.5581 10.2481 12.3572 10.1043C12.1792 9.97675 12.0233 9.82084 11.8957 9.64278C11.7519 9.4419 11.6579 9.20367 11.47 8.72721L10 5Z" ></path>
          </svg>
        </div>
        <div className="stat-title font-">Target</div>
        <div className="stat-value text-[#196A58]">{stats?.totalProductivityPercentage}%</div>
        <div className="stat-desc"> Total Productivity Percentage</div>
      </div>   
       <div className="stat">
        <div className="stat-figure text-[#196A58]">
        <div className="stat-figure text-[#196A58]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            className="inline-block h-8 w-8 stroke-current">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M8 12.3333L10.4615 15L16 9M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" ></path>
          </svg>
        </div>
        </div>
        <div className="stat-value text-[#196A58]">{stats?.totalApprovedForms}</div>
        <div className="stat-title">Total Forms Approved</div>
        <div className="stat-desc text-red-700">{stats?.totalRemainingForms} forms remaining</div>
      </div>
      <div className="stat">
        <div className="stat-figure text-[#196A58]">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            className="inline-block h-8 w-8 stroke-current">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M18.9997 20.5815L16.4179 18.0113M4.9997 20.5815L7.58154 18.0113M11.9997 9.58148V12.5815L13.4416 13.9998M6.74234 3.99735C6.36727 3.62228 5.85856 3.41156 5.32812 3.41156C4.79769 3.41156 4.28898 3.62228 3.91391 3.99735C3.53884 4.37242 3.32813 4.88113 3.32812 5.41156C3.32812 5.942 3.53884 6.4507 3.91391 6.82578M20.0858 6.82413C20.4609 6.44905 20.6716 5.94035 20.6716 5.40991C20.6716 4.87948 20.4609 4.37077 20.0858 3.9957C19.7107 3.62063 19.202 3.40991 18.6716 3.40991C18.1411 3.40991 17.6324 3.62063 17.2574 3.9957M18.9997 12.5815C18.9997 16.4475 15.8657 19.5815 11.9997 19.5815C8.1337 19.5815 4.9997 16.4475 4.9997 12.5815C4.9997 8.71549 8.1337 5.58149 11.9997 5.58149C15.8657 5.58149 18.9997 8.71549 18.9997 12.5815Z"></path>
          </svg>
        </div>
        <div className="stat-title">Total Hours Worked</div>
        <div className="stat-value text-[#196A58]">{stats?.totalHoursWorked}</div>
        <div className="stat-desc">Average {stats?.averageHoursWorked} hours per editor</div>
      </div>
  
    </div>
  );
};

export default StatsComponent;