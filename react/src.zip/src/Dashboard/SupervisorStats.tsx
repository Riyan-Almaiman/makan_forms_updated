import * as React from 'react';
import { BarChart } from '@mui/x-charts/BarChart';

interface SupervisorStatsProps {
  SupervisorStats?: Array<{
    supervisorName: string,
    approved: number,
    rejected: number,
    pending: number
  }>
}

export default function SupervisorStats({ SupervisorStats }: SupervisorStatsProps) {
  const [selectedSupervisor, setSelectedSupervisor] = React.useState<string | 'all'>('all');

  if (!SupervisorStats || SupervisorStats.length === 0) {
    return <div>No supervisor data available</div>;
  }

  const handleSupervisorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedSupervisor(e.target.value);
  };

  // Filter out supervisors with no forms
  const supervisorsWithForms = SupervisorStats.filter(
    stat => stat.approved > 0 || stat.rejected > 0 || stat.pending > 0
  );

  const filteredStats = selectedSupervisor === 'all'
    ? supervisorsWithForms
    : SupervisorStats.filter(stat => stat.supervisorName === selectedSupervisor);

  const supervisorNames = filteredStats.map(stat => stat.supervisorName);
  const approvedData = filteredStats.map(stat => stat.approved);
  const pendingData = filteredStats.map(stat => stat.pending + stat.rejected); // Combine pending and rejected

  const chartData = [
    { data: approvedData, label: 'Approved' },
    { data: pendingData, label: 'Pending' },
  ];

  const chartColors = ['#196A58', '#a1c2c3']; 

  const isAllZero = chartData.every(series => series.data.every(value => value === 0));

  return (
    <div className="w-full max-w-full overflow-x-auto">
      <div className="flex justify-between items-center mb-4">
        <div>
          <label htmlFor="supervisor-select" className="mr-2">Select Supervisor:</label>
          <select
            id="supervisor-select"
            value={selectedSupervisor}
            onChange={handleSupervisorChange}
            className="px-2 py-1 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">All Supervisors</option>
            {SupervisorStats.map(stat => (
              <option key={stat.supervisorName} value={stat.supervisorName}>
                {stat.supervisorName}
              </option>
            ))}
          </select>
        </div>
      </div>
      {isAllZero ? (
        <div className="w-full h-[400px] flex items-center justify-center border border-[#196A58] rounded-md">
          <p className="text-2xl font-bold text-[#196A58]">No data</p>
        </div>
      ) : (
        <BarChart
        barLabel={({ value }) => value !== null ? Math.round(value).toString() : ''}

          series={chartData}
          width={Math.max(600, supervisorNames.length * 100)}
          height={400}
          colors={chartColors}
          xAxis={[{
            data: supervisorNames,
            scaleType: 'band',
            tickLabelStyle: {
              angle: 45,
              textAnchor: 'start',
              fontSize: 10
            }
          }]}
          yAxis={[{
            label: 'Number of Forms',
          }]}
          margin={{ top: 40, bottom: 90, left: 60, right: 40 }}
          slotProps={{
            legend: {
              direction: 'row',
              position: { vertical: 'top', horizontal: 'middle' },
              padding: 5,
            },
          }}
        />
      )}
    </div>
  );
}