import React, { useState } from "react";
import { DateTime } from "luxon";
import { User, Calculation, Product } from "../types";
import FormDetailsModal from "./FormDetailsModal";
import EmployeeDetails from "./EmployeeDetails";
import SupervisorDetails from "./SupervisorDetails";
import DailyTargetList from "./DailyTargetList";
import { validateForm } from "./formUtils";
import { formService } from "../services/formService";
import FormStateDisplay from "./FormStateDisplay";
import { useFormManagement } from "./useFormManagement";

interface Props {
  user: User;
  calculations: Calculation[];
}

const FormComponent: React.FC<Props> = ({ user, calculations }) => {
  const [selectedDate, setSelectedDate] = useState(
    DateTime.now().setZone("Asia/Riyadh").toISODate() || ""
  );
  const [isModalOpen, setIsModalOpen] = useState(false);

  const {
    form,
    setForm,
    formExists,
    setFormExists,
    supervisors,
    handleInputChange,
    handleTargetChange,
    addDailyTarget,
    removeDailyTarget,
    isFormEditable,
  } = useFormManagement(user, selectedDate);


  console.log('product')
console.log(form)

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (validateForm(form)) {
      form.productivityDate = selectedDate;
      form.submissionDate =
        DateTime.now().setZone("Asia/Riyadh").toISOTime() || "";
      console.log(form);
      setIsModalOpen(true);
    }
  };

  const handleModalSubmit = async (comment: string) => {
    const updatedForm = {
      ...form,
      comment,
      ProductivityDate: selectedDate,
      submissionDate: DateTime.now().setZone("Asia/Riyadh").toISO() || "",
    };

    try {
      const resultForm = await formService.CreateOrUpdateForm(updatedForm);
      console.log(resultForm)
      setForm(resultForm);
      setFormExists(true);
      setIsModalOpen(false);
    } catch (error) {
      alert("Error submitting form: " + error);
      console.error("Error submitting form:", error);
    }
  };

  return (
    <div className="rounded-lg flex flex-col h-full">
      <form
        onSubmit={handleFormSubmit}
        className="flex flex-col space-y-6 h-full"
      >
        <h4 className="text-center mb-1 font-bold text-2xl">
          Daily Productivity
        </h4>

        <FormStateDisplay form={form}/>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 shadow-lg bg-[white] p-8 rounded-lg">
          <EmployeeDetails user={user} />
          <div>
            <label
              htmlFor="date"
              className="block text-gray-700 font-bold mb-1"
            >
              Productivity Date:
            </label>
            <input
              required
              type="date"
              id="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <SupervisorDetails
            supervisors={supervisors}
            form={form}
            handleInputChange={handleInputChange}
            isFormDisabled={!isFormEditable}
          />
          <div className="flex flex-col">
            <label
              htmlFor="product"
              className="block text-gray-700 font-bold mb-1"
            >
              Product
            </label>
            <select
              id="product"
              name="product"
              value={form.product || ""}
              onChange={handleInputChange}
              className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
              disabled={!isFormEditable}
            >
              <option value="" disabled>
                Select a Product
              </option>
              {Object.values(Product).map((value) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ))}
            </select>
          </div>
        </div>

        <DailyTargetList
          calculations={calculations}
          dailyTargets={form.dailyTargets || []}
          product={form.product || ""}
          handleTargetChange={handleTargetChange}
          addDailyTarget={addDailyTarget}
          removeDailyTarget={removeDailyTarget}
          isFormDisabled={!isFormEditable}
          supervisorSelected={!!form.supervisorTaqniaID}
        />

        <div className="mt-4 flex justify-center flex-shrink-0">
          <button
            type="submit"
            className={`bg-[#196A58] hover:bg-green-700 text-white font-bold py-2 px-6 rounded-md focus:outline-none focus:ring-2 mb-2 focus:ring-blue-500 ${
              !isFormEditable ? "opacity-50 cursor-not-allowed" : ""
            }`}
            disabled={!isFormEditable}
          >
            {formExists ? "Update Form" : "Submit New Form"}
          </button>
        </div>
      </form>

      <FormDetailsModal
        calculations={calculations}
        form={form}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleModalSubmit}
      />
    </div>
  );
};

export default FormComponent;
