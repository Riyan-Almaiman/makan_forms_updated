import React, { useEffect, useState } from "react";
import { DailyTarget, Calculation, calculateExpectedProductivityForTarget} from "../types";

interface Props {
    index: number;
    target: DailyTarget;
    handleTargetChange: (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
    removeDailyTarget: (index: number) => void;
    isFormDisabled: boolean;
    product: string; 
    calculations: Calculation[] | undefined;
}

const DailyTargetItem = ({ index, target, product, handleTargetChange, removeDailyTarget, isFormDisabled, calculations }: Props) => {
    const [expectedProductivity, setExpectedProductivity] = useState<number>(0);
    const [availableLayers, setAvailableLayers] = useState<string[]>([]);
    const [availableRemarks, setAvailableRemarks] = useState<string[]>([]);
    const [availableTargetTypes, setAvailableTargetTypes] = useState<string[]>([]);
    console.log(product)
    console.log(target.layers)
    console.log(target.remarks)
    console.log(target.targetType)
    useEffect(() => {
        if (calculations) {
            const layers = [...new Set(calculations
                .filter(c => c.product === product)
                .map(c => c.layer))];
            setAvailableLayers(layers);
        }
    }, [calculations, product]);

    useEffect(() => {
        if (calculations && target.layers) {
            const remarks = [...new Set(calculations
                .filter(c => c.product === product && c.layer === target.layers)
                .map(c => c.remark))];
            setAvailableRemarks(remarks);
        }
    }, [calculations, target.layers, product]);

    useEffect(() => {
        if (calculations && target.layers && target.remarks) {
            const targetTypes = [...new Set(calculations
                .filter(c => c.product === product && c.layer === target.layers && c.remark === target.remarks)
                .map(c => c.targetType))];
            setAvailableTargetTypes(targetTypes);
        }
    }, [calculations, target.layers, target.remarks, product]);

    useEffect(() => {
        if (calculations) {
            const expected = calculateExpectedProductivityForTarget(target, calculations);
            setExpectedProductivity(expected);
        }
    }, [target, calculations]);

    return (
        <div key={index} className="w-full bg-gray-100 rounded-lg shadow-md p-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="flex flex-col">
                    <label htmlFor={`layers-${index}`} className="block text-gray-700 text-sm font-bold mb-2">
                        Layers
                    </label>
                    <select
                        id={`layers-${index}`}
                        name="layers"
                        value={target.layers || ""}
                        onChange={(e) => handleTargetChange(index, e)}
                        className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        disabled={isFormDisabled}
                    >
                        <option value="" disabled>Select Layer</option>
                        {availableLayers.map((layer) => (
                            <option key={layer} value={layer}>
                                {layer}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="flex flex-col">
                    <label htmlFor={`remarks-${index}`} className="block text-gray-700 text-sm font-bold mb-2">
                        Remarks
                    </label>
                    <select
                        id={`remarks-${index}`}
                        name="remarks"
                        value={target.remarks || ""}
                        onChange={(e) => handleTargetChange(index, e)}
                        className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        disabled={isFormDisabled}
                    >
                        <option value="" disabled>Select Remark</option>
                        {availableRemarks.map((remark) => (
                            <option key={remark} value={remark}>
                                {remark}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="flex flex-col">
                    <label htmlFor={`targetType-${index}`} className="block text-gray-700 text-sm font-bold mb-2">
                        Target Type
                    </label>
                    <select
                        id={`targetType-${index}`}
                        name="targetType"
                        value={target.targetType || ""}
                        onChange={(e) => handleTargetChange(index, e)}
                        className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        disabled={isFormDisabled}
                    >
                        <option value="" disabled>Select Target Type</option>
                        {availableTargetTypes.map((type) => (
                            <option key={type} value={type}>{type}</option>
                        ))}
                    </select>
                </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="flex flex-col">
                    <label htmlFor={`hoursWorked-${index}`} className="block text-gray-700 text-sm font-bold mb-2">
                        Hours Worked
                    </label>
                    <input
                        type="number"
                        id={`hoursWorked-${index}`}
                        name="hoursWorked"
                        value={target.hoursWorked}
                        onChange={(e) => handleTargetChange(index, e)}
                        className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        disabled={isFormDisabled}
                    />
                </div>
                <div className="flex flex-col">
                    <label htmlFor={`productivity-${index}`} className="block text-gray-700 text-sm font-bold mb-2">
                        <span>Productivity</span>
                        <span className="text-gray-500 text-sm font-normal ml-2">(Expected: {expectedProductivity.toFixed(2)})</span>
                    </label>
                    <input
                        type="number"
                        id={`productivity-${index}`}
                        name="productivity"
                        value={target.productivity}
                        onChange={(e) => handleTargetChange(index, e)}
                        className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                        disabled={isFormDisabled}
                    />
                </div>
            </div>
            <div className="mt-4 flex justify-end">
                <button
                    type="button"
                    onClick={() => removeDailyTarget(index)}
                    className={`bg-transparent hover:bg-red-500 text-white font-bold py-2 px-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        isFormDisabled ? "opacity-50 cursor-not-allowed" : ""
                    }`}
                    disabled={isFormDisabled}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 stroke-black h-6" viewBox="0 0 24 24">
                        <g id="Trash" data-name="Trash">
                            <g>
                                <path d="M19.45,4.06H15.27v-.5a1.5,1.5,0,0,0-1.5-1.5H10.23a1.5,1.5,0,0,0-1.5,1.5v.5H4.55a.5.5,0,0,0,0,1h.72l.42,14.45a2.493,2.493,0,0,0,2.5,2.43h7.62a2.493,2.493,0,0,0,2.5-2.43l.42-14.45h.72A.5.5,0,0,0,19.45,4.06Zm-9.72-.5a.5.5,0,0,1,.5-.5h3.54a.5.5,0,0,1,.5.5v.5H9.73Zm7.58,15.92a1.5,1.5,0,0,1-1.5,1.46H8.19a1.5,1.5,0,0,1-1.5-1.46L6.26,5.06H17.74Z" />
                                <path d="M8.375,8h0a.5.5,0,0,1,1,0l.25,10a.5.5,0,0,1-1,0Z" />
                                <path d="M15.625,8.007a.5.5,0,0,0-1,0h0l-.25,10a.5.5,0,0,0,1,0Z" />
                            </g>
                        </g>
                    </svg>
                </button>
            </div>
        </div>
    );
};

export default DailyTargetItem;