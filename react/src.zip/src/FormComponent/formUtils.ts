import { DailyTarget, Form, User } from "../types";

export const initialTarget = (): DailyTarget => ({
  hoursWorked: 0,
  productivity: 0,
  targetType: null,
  remarks: null,
  layers: null,
  formId: 0,
  expectedProductivity: 0, 
});

export const initialForm = (user: User): Form => ({
  comment: null,
  product: "",
  productivityDate: "",
  submissionDate: "",
  employeeName: user.name,
  supervisorTaqniaID: user.supervisorTaqniaID,
  dailyTargets: [initialTarget()],
  taqniaID: user.taqniaID
});

export const validateForm = (form: Form) => {
  if (!form.dailyTargets || form.dailyTargets.length === 0) {
    alert("Add at least one target");
    return false;
  }

  const totalHours = form.dailyTargets.reduce((sum, target) => sum + Number(target.hoursWorked), 0);
  if (totalHours === 0 || totalHours > 12) {
    alert("Total hours worked must be between 1 and 12.");
    return false;
  }

  for (const target of form.dailyTargets) {
    if (target.hoursWorked <= 0) {
      alert("Each target's hours worked must be greater than 0.");
      return false;
    }
    if (target.productivity <= 0) {
      alert("Each target's productivity must be greater than 0.");
      return false;
    }
    if (!target.targetType || !target.remarks || !target.layers) {
      alert("Each target must have a target type, remarks, and layers.");
      return false;
    }
  }

  if (!form.product) {
    alert("Please select a product.");
    return false;
  }

  return true;
};