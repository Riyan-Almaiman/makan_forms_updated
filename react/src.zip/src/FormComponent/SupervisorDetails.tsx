// src/components/SupervisorDetails.tsx

import React from "react";
import { User, Form } from "../types";

interface Props {
  supervisors: User[];
  form: Form;
  handleInputChange: (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement | HTMLSelectElement>) => void;
  isFormDisabled: boolean;
}
const SupervisorDetails = ({ supervisors, form, handleInputChange, isFormDisabled }: Props) => {
  return (
    <div>
      <label htmlFor="supervisorTaqniaID" className="block text-gray-700 text-sm font-bold mb-2">
        Supervisor
      </label>
      <select
        id="supervisorTaqniaID"
        name="supervisorTaqniaID"
        value={form.supervisorTaqniaID || 0}
        onChange={handleInputChange}
        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        required
        disabled={isFormDisabled}
      >
        <option value="">Select a supervisor</option>
        {supervisors.map((supervisor) => (
          <option key={supervisor.taqniaID} value={supervisor.taqniaID || ""}>
            {supervisor.name}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SupervisorDetails;
