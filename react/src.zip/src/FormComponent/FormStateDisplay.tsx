import React from 'react';
import { Form, FormState } from '../types';

interface FormStateDisplayProps {
    form: Form;
}

const FormStateDisplay: React.FC<FormStateDisplayProps> = ({ form }) => {
    const getFormState = (form: Form): FormState => {
        if (!form.approvals || form.approvals.length === 0) return "New";
        const firstApproval = form.approvals[0];
        return firstApproval.state as FormState|| "pending";
    };

    const formState = getFormState(form);

    if (formState === "New") return null;

    return (
        <>
            {formState === "pending" && (
                <div className="font-bold bg-yellow-100 rounded p-4 text-yellow-600">
                    Your form is pending review.
                </div>
            )}
            {formState === "rejected" && (
                <div className="bg-red-100 p-4 font-bold text-red-600 whitespace-normal break-words">
                    Your form was rejected. Supervisor comments: {form.approvals?.[0].supervisorComment}
                </div>
            )}
            {formState === "approved" && (
                <div className="bg-green-100 p-4 font-bold text-green-600 whitespace-normal break-words">
                    Your form was accepted. Supervisor Comments: {form.approvals?.[0].supervisorComment}
                </div>
            )}
        </>
    );
};

export default FormStateDisplay;