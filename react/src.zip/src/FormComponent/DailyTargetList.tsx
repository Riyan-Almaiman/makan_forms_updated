import React from "react";
import { FaCirclePlus } from "react-icons/fa6";
import { Calculation, DailyTarget } from "../types";
import DailyTargetItem from "./DailyTargetItem";

interface Props {
    dailyTargets: DailyTarget[];
    handleTargetChange: (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
    addDailyTarget: () => void;
    removeDailyTarget: (index: number) => void;
    isFormDisabled: boolean;
    calculations: Calculation[] | undefined;
    product: string;
    supervisorSelected: boolean; // New prop to check if supervisor is selected
}

const DailyTargetList = ({ calculations, product, dailyTargets, handleTargetChange, addDailyTarget, removeDailyTarget, isFormDisabled, supervisorSelected }: Props) => {
    const targetsDisabled = isFormDisabled || !product || !supervisorSelected;
    console.log('product from list:')
    console.log(product)
    return (
        <div className="flex flex-col bg-white shadow-sm rounded-lg flex-grow">
            <div className="flex flex-col items-center space-y-4 p-4">
                {dailyTargets.map((target, index) => (
                    <DailyTargetItem
                        key={index}
                        index={index}
                        product={product}
                        target={target}
                        handleTargetChange={handleTargetChange}
                        removeDailyTarget={removeDailyTarget}
                        isFormDisabled={targetsDisabled}
                        calculations={calculations}
                    />
                ))}
            </div>
            <div className="mt-4 flex justify-center">
                <button
                    type="button"
                    onClick={addDailyTarget}
                    className={`bg-gray-400 hover:bg-green-700 mb-2 text-white font-bold py-2 px-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        targetsDisabled ? "opacity-50 cursor-not-allowed" : ""
                    }`}
                    disabled={targetsDisabled}
                >
                    <FaCirclePlus />
                </button>
            </div>
        </div>
    );
};

export default DailyTargetList;
