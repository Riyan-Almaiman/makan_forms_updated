// src/components/EmployeeDetails.tsx

import { User } from "../types";

interface Props {
  user: User;
}

const EmployeeDetails = ({ user }: Props) => {
  return (
    <div>
      <label htmlFor="employeeName" className="block text-gray-700 text-sm font-bold mb-2">
        Employee Name
      </label>
      <input
        type="text"
        id="employeeName"
        name="employeeName"
        value={user.name || ""} 
        disabled
        className="w-full px-4 py-2 border bg-gray-200 border-gray-300 rounded-md"
      />
    </div>
  );
};

export default EmployeeDetails;
