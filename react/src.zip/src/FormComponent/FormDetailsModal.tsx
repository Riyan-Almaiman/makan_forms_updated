import React, { useState } from "react";
import { Form, Calculation } from "../types";
import { DateTime } from "luxon";
import { calculateExpectedProductivityForTarget } from "../types";

interface FormDetailsModalProps {
    form: Form;
    isOpen: boolean;
    calculations: Calculation[] | undefined;
    onClose: () => void;
    onSubmit: (comment: string) => void;
}

const FormDetailsModal: React.FC<FormDetailsModalProps> = ({ calculations, form, isOpen, onClose, onSubmit }) => {
    const [comment, setComment] = useState("");

    const formatDateTime = (dateTimeString: string): string => {
        return DateTime.fromISO(dateTimeString).toFormat("dd/MM/yyyy HH:mm:ss");
    };

    const handleSubmit = () => {
        console.log(comment);
        onSubmit(comment);
        setComment("");
    };

    if (!isOpen) return null;

    return (
        <dialog id="form_modal" className={`modal ${isOpen ? 'modal-open' : ''}`}>
            <div className="modal-box max-w-4xl bg-white rounded-lg shadow-xl">
                <h3 className="font-bold text-2xl mb-6 text-[#196A58]">Form Details</h3>
                
                <div className="grid grid-cols-2 gap-4 mb-6 bg-gray-50 p-4 rounded-lg">
                    <div>
                        <p><span className="font-semibold">Employee Name:</span> {form.employeeName}</p>
                        <p><span className="font-semibold">Product:</span> {form.product}</p>
                    </div>
                    <div>
                        <p><span className="font-semibold">Productivity Date:</span> {form.productivityDate ? DateTime.fromISO(form.productivityDate).toFormat('dd/MM/yyyy') : 'N/A'}</p>
                        <p><span className="font-semibold">Form Submission:</span> {formatDateTime(form.submissionDate)}</p>
                    </div>
                </div>

                <div className="overflow-x-auto mb-6">
                    <table className="table w-full">
                        <thead>
                            <tr className="bg-gray-100">
                                <th>Layer</th>
                                <th>Target Type</th>
                                <th>Productivity</th>
                                <th>Expected</th>
                                <th>Hours</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            {form.dailyTargets?.map((dt, index) => {
                                const expectedProductivity = calculations ? 
                                    calculateExpectedProductivityForTarget(dt, calculations) : 0;
                                
                                return (
                                    <tr key={index} className="hover:bg-gray-50">
                                        <td>{dt.layers}</td>
                                        <td>{dt.targetType}</td>
                                        <td>{dt.productivity.toString().replace(/^0+/, '')}</td>
                                        <td>{expectedProductivity.toFixed(2)}</td>
                                        <td>{dt.hoursWorked.toString().replace(/^0+/, '')}</td>
                                        <td>{dt.remarks}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>

                <div className="form-control mb-6">
                    <label className="label">
                        <span className="label-text font-semibold">Your Comment:</span>
                    </label>
                    <textarea
                        value={comment}
                        onChange={(e) => setComment(e.currentTarget.value)}
                        placeholder="Add your comment here"
                        className="textarea textarea-bordered h-24"
                    ></textarea>
                </div>

                <div className="modal-action">
                    <button 
                        className="btn btn-primary bg-[#196A58] hover:bg-[#124E3F]"
                        onClick={handleSubmit}
                    >
                        Confirm
                    </button>
                    <button className="btn" onClick={onClose}>Close</button>
                </div>
            </div>
        </dialog>
    );
};

export default FormDetailsModal;