import { useState, useEffect } from 'react';
import { User, Form, FormState } from '../types';
import { initialForm, initialTarget } from './formUtils';
import { userService } from '../services/userService';
import { formService } from '../services/formService';

export const useFormManagement = (user: User, selectedDate: string) => {
    const [form, setForm] = useState<Form>(initialForm(user));
    const [formExists, setFormExists] = useState(false);
    const [supervisors, setSupervisors] = useState<User[]>([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const formData = await formService.getUserFormByDate(user.taqniaID, selectedDate);
                const supervisorsData = await userService.getUsersByRole("supervisor");
                console.log(formData)
                setSupervisors(supervisorsData);
                if (formData) {
                    setForm(formData);
                    setFormExists(true);
                } else {
                    setForm(initialForm(user));
                    setFormExists(false);
                }
            } catch (error) {
                console.error("Error fetching data:", error);
                if (error instanceof Error) {
                    console.error("Error message:", error.message);
                }
            }
        };
        fetchData();
    }, [selectedDate, user]);

    const getFormState = (form: Form): FormState => {
        if (!form.approvals || form.approvals.length === 0) return "New";
        const firstApproval = form.approvals[0];
        return firstApproval.state as FormState || "pending" as FormState;
    };

    const formState = getFormState(form);

    const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setForm(prevForm => ({ ...prevForm, [name]: value }));
    };

    const handleTargetChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setForm(prevForm => ({
            ...prevForm,
            dailyTargets: prevForm.dailyTargets?.map((target, i) => 
                i === index ? { ...target, [name]: value } : target
            ) || []
        }));
    };
    const addDailyTarget = () => {
        setForm(prevForm => ({
            ...prevForm,
            dailyTargets: [...(prevForm.dailyTargets || []), initialTarget()]
        }));
    };

    const removeDailyTarget = (index: number) => {
        setForm(prevForm => ({
            ...prevForm,
            dailyTargets: prevForm.dailyTargets?.filter((_, i) => i !== index) || []
        }));
    };

    const isFormEditable = formState === "New" || formState === "rejected" || formState === "pending";

    return {
        form,
        setForm,
        formExists,
        setFormExists,
        supervisors,
        formState,
        handleInputChange,
        handleTargetChange,
        addDailyTarget,
        removeDailyTarget,
        isFormEditable
    };
};