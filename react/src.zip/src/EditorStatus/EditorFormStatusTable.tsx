// import React, { useEffect, useState } from "react";
//  import { fetchEditorFormStatus } from "../Fetch"; // Adjust the import path as necessary
//  import { EditorFormStatus, User } from "../types"; // Adjust the import path as necessary
// import * as XLSX from "xlsx";
// import { saveAs } from "file-saver";
// import { DateTime } from "luxon";

// interface EditorFormStatusTableProps {
//     user: User;
// }

// const EditorFormStatusTable  = ({user} : EditorFormStatusTableProps) => {
//     const today = DateTime.now().setZone("Asia/Riyadh").toISODate() || "";

//     const [data, setData] = useState<EditorFormStatus[]>([]);
//     const [loading, setLoading] = useState<boolean>(false);
//     const [error, setError] = useState<string | null>(null);
//     const [selectedDate, setSelectedDate] = useState<string>(today);
//     const [selectedSupervisor, setSelectedSupervisor] = useState<string>(
//         user.role === "supervisor" ? user.name : "All"
//     );
//     const [filter, setFilter] = useState<string>("All");

//     useEffect(() => {
//         const fetchData = async () => {
//             if (!selectedDate) return;
//             setLoading(true);
//             try {
//                 const fetchedData = await fetchEditorFormStatus(selectedDate);
//                 setData(fetchedData);
//             } catch (err) {
//                 if (err instanceof Error) {
//                     setError(err.message);
//                 } else {
//                     setError("An unknown error occurred");
//                 }
//             } finally {
//                 setLoading(false);
//             }
//         };

//         fetchData();
//     }, [selectedDate]);

//     const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//         setSelectedDate(e.target.value);
//         setError(null);
//         setData([]);
//     };

//     const handleSupervisorChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
//         setSelectedSupervisor(e.target.value);
//     };

//     const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
//         setFilter(e.target.value);
//     };

//     const handleExport = () => {
//         const data = filteredData.map((item) => ({
//             "Editor Name": item.editor.name,
//             "Supervisor Name": item.supervisorName,
//             Status: item.formStatus,
//         }));
//         const ws = XLSX.utils.json_to_sheet(data);
//         const wb = XLSX.utils.book_new();
//         XLSX.utils.book_append_sheet(wb, ws, "EditorFormStatus");

//         const exportDate = selectedDate ? selectedDate : "all";
//         const fileName = `${exportDate}_EditorFormStatus.xlsx`;

//         const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
//         const blob = new Blob([wbout], { type: "application/octet-stream" });
//         saveAs(blob, fileName);
//     };

//     const filteredData = data.filter((item) => 
//         (filter === "All" || item.formStatus === filter || (filter === "No form" && item.formStatus === "No form")) &&
//         (selectedSupervisor === "All" || item.supervisorName === selectedSupervisor)
//     );

//      const uniqueSupervisorNames = ["All", ...new Set(data.map((item) => item.supervisorName))];

//     return (
//         <div className="flex flex-col h-full p-4">
//             <div className="mb-1">
//                 <label htmlFor="date" className="block text-gray-700 font-bold mb-2">
//                     Select Date:
//                 </label>
//                 <input
//                     type="date"
//                     id="date"
//                     value={selectedDate}
//                     onChange={handleDateChange}
//                     className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
//                 />
//             </div>
//             {selectedDate && (
//                 <>
//                     <div className="mb-1">
//                         <label htmlFor="supervisor" className="block text-gray-700 font-bold ">
//                             Filter by Supervisor:
//                         </label>
//                         <select
//                             id="supervisor"
//                             value={selectedSupervisor}
//                             onChange={handleSupervisorChange}
//                             className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
//                         >
//                             {uniqueSupervisorNames.map((name) => (
//                                 <option key={name} value={name}>
//                                     {name}
//                                 </option>
//                             ))}
//                         </select>
//                     </div>
//                     <div className="mb-4">
//                         <label htmlFor="filter" className="block text-gray-700 font-bold mb-2">
//                             Filter by Status:
//                         </label>
//                         <select
//                             id="filter"
//                             value={filter}
//                             onChange={handleFilterChange}
//                             className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
//                         >
//                             <option value="All">All</option>
//                             <option value="submitted">Submitted</option>
//                             <option value="approved">Approved</option>
//                             <option value="rejected">Rejected</option>
//                             <option value="No form">No form</option>
//                         </select>
//                     </div>
                  
//                     <div className="flex-grow overflow-hidden">
//                         <div className="overflow-y-auto h-full">
//                             {loading ? (
//                                 <div className="font-bold text-lg ml-1">Loading data...</div>
//                             ) : error ? (
//                                 <div className="font-bold text-lg ml-1 text-red-600">Error: {error}</div>
//                             ) : filteredData.length === 0 ? (
//                                 <div className="font-bold text-lg ml-1 text-gray-700">No data available for the selected filters.</div>
//                             ) : (
//                                 <table className="min-w-full table table-zebra bg-gray-200 rounded-lg">
//                                     <thead>
//                                         <tr>
//                                             <th>Editor Name</th>
//                                             <th>Supervisor Name</th>
//                                             <th>Status</th>
//                                         </tr>
//                                     </thead>
//                                     <tbody>
//                                         {filteredData.map((item, index) => (
//                                             <tr key={index}>
//                                                 <td>{item.editor.name}</td>
//                                                 <td>{item.supervisorName}</td>
//                                                 <td>
//                                                     {item.formStatus === "submitted" ? (
//                                                         <span className="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
//                                                             {item.formStatus}
//                                                         </span>
//                                                     ) : item.formStatus === "approved" ? (
//                                                         <span className="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-green-100 text-green-800">
//                                                             {item.formStatus}
//                                                         </span>
//                                                     ) : item.formStatus === "rejected" ? (
//                                                         <span className="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-red-100 text-red-800">
//                                                             {item.formStatus}
//                                                         </span>
//                                                     ) : (
//                                                         <span className="inline-flex items-center gap-x-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-red-300 text-red-800">
//                                                             {item.formStatus}
//                                                         </span>
//                                                     )}
//                                                 </td>
//                                             </tr>
//                                         ))}
//                                     </tbody>
//                                 </table>
//                             )}
//                         </div>
//                     </div>
//                     <div className="mt-2 justify-center flex">
//                         <button
//                             onClick={handleExport}
//                             className="px-4 py-2 font-semibold text-white bg-[#196A58] rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                         >
//                             Export to Excel
//                         </button>
//                     </div>
//                 </>
//             )}
//         </div>
//     );
// };

// export default EditorFormStatusTable;
