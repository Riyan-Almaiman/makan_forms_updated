import { useState, useEffect } from "react";
import Cookies from "js-cookie";
import Login from "./Login";
import FormComponent from "./FormComponent/FormComponent";
import { User, Calculation } from "./types";
import SideBar from "./Sidebar/SideBar";
import CreateUser from "./CreateUser";
import Calculations from "./Productivity/Calculations";
import Dashboard from "./Dashboard/Dashboard";
import SupervisorTable from "./SupervisorTable/SupervisorTable";
//import EditorFormStatusTable from "./EditorStatus/EditorFormStatusTable";
import { userService } from "./services/userService"; // Import the userService
import { calculationService } from "./services/calculationService";
import Settings from "./Settings";
function App() {
    const [user, setUser] = useState<User | null>(null);
    const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [calculations, setCalculations] = useState<Calculation[]>([]);
    useEffect(() => {
     

        fetchData();
    }, []);

    const handleUserUpdate = (updatedUser: User) => {
        setUser(updatedUser);
        Cookies.set("user", JSON.stringify(updatedUser), { expires: 1 });
      };
    
    const fetchData = async () => {
        try {
            const calculationsData = await calculationService.getAllCalculations();
            console.log(calculationsData)
            setCalculations(calculationsData);
        } catch (error) {
            console.error("Error fetching calculations:", error);
        }
    };
    const handleLogin = async (credentials: { username: string; password: string }) => {
        try {
            const user = await userService.login(credentials.username, credentials.password);
            setUser(user);
            Cookies.set("user", JSON.stringify(user), { expires: 1 });
        } catch (error) {
            console.error("Error during login:", error);
            throw new Error("Login failed");
        }
    };
    
    useEffect(() => {
        const checkUser = async () => {
            const userCookie = Cookies.get("user");
            if (userCookie) {
                const parsedUser: User = JSON.parse(userCookie);
                try {
                    const validUser = await userService.validateUser(parsedUser.taqniaID);
                    setUser(validUser);
                } catch (error) {
                    console.error("Error validating user:", error);
                    Cookies.remove("user");
                }
            }
        };
    
        checkUser();
    }, []);

    const handleLogout = () => {
        Cookies.remove("user");
        setUser(null);
        setSelectedComponent(null);
    };
    const handleNavigate = (component: string) => {
        console.log("Navigating to:", component);
        setSelectedComponent(component);
    };

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const renderComponent = () => {
        console.log("Rendering component:", selectedComponent);
        if (!user) {
            return <Login onLogin={handleLogin} />;
        }
    
        switch (selectedComponent) {
            case "Forms":
                return <FormComponent user={user} calculations={calculations} />;
            case "Users":
                return <CreateUser />;
            case "Targets":
                return <Calculations user={user} calculations={calculations} />;
            case "Submissions":
                return <SupervisorTable calculations={calculations} user={user} />;
            case "Dashboard":
                return <Dashboard   />;
            case "Settings":
                return <Settings user={user!} onUserUpdate={handleUserUpdate} />;
            default:
                return null;
        }
    };

    return (
        <div className="flex h-screen">
            {user && (
                <>
                    <button
                        className="fixed z-30 flex items-center justify-center p-2 bg-[#196A58] rounded-full top-2 left-2 md:hidden"
                        onClick={toggleSidebar}
                    >
                        <svg
                            className="w-6 h-6"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M4 6H20M4 12H20M4 18H20"
                                className="stroke-gray-100"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />
                        </svg>
                    </button>
                    <SideBar
                        user={user}
                        onNavigate={handleNavigate}
                        onLogout={handleLogout}
                        isSidebarOpen={isSidebarOpen}
                        toggleSidebar={toggleSidebar}
                    />
                </>
            )}
            <div className={`flex-1 p-6 overflow-auto ${user ? "md:ml-64" : "w-full flex items-center justify-center"}`}>
                {renderComponent()}
            </div>
        </div>
    );
}

export default App;