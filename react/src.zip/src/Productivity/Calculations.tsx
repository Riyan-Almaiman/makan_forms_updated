/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState, useEffect } from 'react';
import { Calculation, User } from '../types';
import { calculationService } from '../services/calculationService';
import { Layer, Remark, TargetType, Product } from '../types';

interface Props {
    user: User;
    calculations: Calculation[];
}

const Calculations: React.FC<Props> = ({ user, calculations }) => {
    const [editedCalculations, setEditedCalculations] = useState<Calculation[]>([]);
    const [isEditing, setIsEditing] = useState<boolean>(false);
    const [selectedCategory, setSelectedCategory] = useState<string>(Product.TDS7);
    const [selectedLayer, setSelectedLayer] = useState<string>('');
    const [newCalculation, setNewCalculation] = useState<Partial<Calculation>>({
        layer: '',
        remark: '',
        valuePer8Hours: 0,
        valuePerHour: 0,
        targetType: TargetType.KM,
        product: '',
    });

    useEffect(() => {
        setEditedCalculations(calculations);
    }, [calculations]);

    const handleEditClick = () => {
        setIsEditing(true);
    };

    const handleSaveClick = async () => {
        try {
            await Promise.all(editedCalculations.map(calculation => 
                calculationService.updateCalculation(calculation.calculationId!, calculation)
            ));
            setIsEditing(false);
        } catch (error) {
            console.error('Error saving calculations:', error);
        }
    };

    const handleValueChange = (id: number, field: keyof Calculation, value: any) => {
        setEditedCalculations(prevCalculations => 
            prevCalculations.map(calculation => {
                if (calculation.calculationId === id) {
                    const updatedCalculation = { ...calculation, [field]: value };
                    if (field === 'valuePer8Hours') {
                        updatedCalculation.valuePerHour = value / 8;
                    }
                    return updatedCalculation;
                }
                return calculation;
            })
        );
    };

    const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedCategory(e.target.value);
    };

    const handleLayerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedLayer(e.target.value);
    };

    const handleNewCalculationChange = (field: keyof Partial<Calculation>, value: any) => {
        setNewCalculation(prev => {
            const updated = { ...prev, [field]: value };
            if (field === 'valuePer8Hours') {
                updated.valuePerHour = value / 8;
            }
            return updated;
        });
    };

    const handleAddCalculation = async () => {
        if (newCalculation.product && newCalculation.layer && newCalculation.remark && newCalculation.valuePer8Hours && newCalculation.targetType) {
            const isDuplicate = editedCalculations.some(calculation =>
                calculation.product === newCalculation.product &&
                calculation.layer.toLowerCase() === newCalculation.layer?.toLowerCase() &&
                calculation.remark.toLowerCase() === newCalculation.remark?.toLowerCase() &&
                calculation.targetType === newCalculation.targetType
            );

            if (isDuplicate) {
                alert("A calculation with the same product, layer, remark, and target type already exists.");
                return;
            }

            try {
                const addedCalculation = await calculationService.createCalculation(newCalculation as Calculation);
                setEditedCalculations([...editedCalculations, addedCalculation]);
                setNewCalculation({ 
                    product: '',
                    layer: '', 
                    remark: '', 
                    valuePer8Hours: 0, 
                    valuePerHour: 0, 
                    targetType: TargetType.KM 
                });
            } catch (error) {
                console.error('Error adding calculation:', error);
            }
        } else {
            alert("Please fill in all fields for the new target type.");
        }
    };

    const handleDeleteCalculation = async (id: number) => {
        try {
            await calculationService.deleteCalculation(id);
            setEditedCalculations(editedCalculations.filter(calculation => calculation.calculationId !== id));
        } catch (error) {
            console.error('Error deleting calculation:', error);
        }
    };

    const filteredCalculations = editedCalculations.filter((calculation) =>
        calculation.product === selectedCategory && (!selectedLayer || calculation.layer === selectedLayer)
    );

    return (
        <div className="container mx-auto p-4">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-2xl font-bold">Daily Targets</h3>
            </div>
            {(user.role === 'admin' || user.role === 'superadmin') && (
                <div className="mb-4 bg-gray-200 p-4 rounded-lg">
                    <h4 className="text-sm font-semibold mb-2">Add New Target Type</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-2">
                        <select
                            value={newCalculation.product || ''}
                            onChange={(e) => handleNewCalculationChange('product', e.target.value)}
                            className="w-full p-1 border rounded text-sm"
                        >
                            <option value="" disabled>Select Product</option>
                            {Object.values(Product).map((product) => (
                                <option key={product} value={product}>{product}</option>
                            ))}
                        </select>
                        <select
                            value={newCalculation.layer || ''}
                            onChange={(e) => handleNewCalculationChange('layer', e.target.value)}
                            className="w-full p-1 border rounded text-sm"
                        >
                            <option value="" disabled>Select Layer</option>
                            {Object.values(Layer).map((layer) => (
                                <option key={layer} value={layer}>{layer}</option>
                            ))}
                        </select>
                        <select
                            value={newCalculation.remark || ''}
                            onChange={(e) => handleNewCalculationChange('remark', e.target.value)}
                            className="w-full p-1 border rounded text-sm"
                        >
                            <option value="" disabled>Select Remark</option>
                            {Object.values(Remark).map((remark) => (
                                <option key={remark} value={remark}>{remark}</option>
                            ))}
                        </select>
                        <input
                            type="number"
                            value={newCalculation.valuePer8Hours || ''}
                            onChange={(e) => handleNewCalculationChange('valuePer8Hours', parseFloat(e.currentTarget.value))}
                            placeholder="Productivity for 8 hours"
                            className="w-full p-1 border rounded text-sm"
                        />
                        <select
                            value={newCalculation.targetType || TargetType.KM}
                            onChange={(e) => handleNewCalculationChange('targetType', e.currentTarget.value )}
                            className="w-full p-1 border rounded text-sm"
                        >
                            {Object.values(TargetType).map((type) => (
                                <option key={type} value={type}>{type}</option>
                            ))}
                        </select>
                        <button
                            onClick={handleAddCalculation}
                            className="px-2 py-1 bg-[#196A58] text-white rounded text-sm"
                        >
                            Add
                        </button>
                    </div>
                </div>
            )}

            <div className='bg-gray-200 p-8 rounded-lg'>
                <div className="flex justify-between items-center mb-4">
                    <div className="flex mb-4 space-x-4">
                        <div className="flex-1">
                            <label htmlFor="category" className="block text-sm font-medium mb-1">Product:</label>
                            <select
                                id="category"
                                value={selectedCategory}
                                onChange={handleCategoryChange}
                                className="w-full p-1 text-sm border rounded"
                            >
                                {Object.values(Product).map((product) => (
                                    <option key={product} value={product}>{product}</option>
                                ))}
                            </select>
                        </div>
                        <div className="flex-2">
                            <label htmlFor="layer" className="block text-sm font-medium mb-1">Layer:</label>
                            <select
                                id="layer"
                                value={selectedLayer}
                                onChange={handleLayerChange}
                                className="w-full p-1 text-sm border rounded"
                            >
                                <option value="">All Layers</option>
                                {Object.values(Layer).map((layer) => (
                                    <option key={layer} value={layer}>{layer}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                    {(user.role === 'admin' || user.role === 'superadmin') && (
                        isEditing ? (
                            <button
                                onClick={handleSaveClick}
                                className="px-4 py-2 bg-[#196A58] text-white rounded"
                            >
                                Save
                            </button>
                        ) : (
                            <button
                                onClick={handleEditClick}
                                className="px-4 py-2 bg-[#196A58] text-lg text-white rounded"
                            >
                                Edit
                            </button>
                        )
                    )}
                </div>
            <div className="overflow-auto table table-zebra	">
                <table className="min-w-full">
                    <thead className='border-b-2 border-slate-400'>
                        <tr>
                            <th className="py-2 px-4 border-b text-center">Layer</th>
                            <th className="py-2 px-4 border-b text-center">Remark</th>
                            <th className="py-2 px-4 border-b text-center">Productivity for 8 hours</th>
                            <th className="py-2 px-4 border-b text-center">Hourly Value</th>
                            <th className="py-2 px-4 border-b text-center">Target Type</th>
                            {(user.role === 'admin' || user.role === 'superadmin') && <th className="py-2 px-4 border-b text-center"></th>}
                        </tr>
                    </thead>

                    <tbody>
                        {filteredCalculations.map((calculation) => (
                            <tr key={calculation.calculationId}>
                                <td className="py-2 px-4 border-b text-center">
                                    {isEditing ? (
                                        <select
                                            value={calculation.layer}
                                            onChange={(e) =>
                                                handleValueChange(calculation.calculationId!, 'layer', e.target.value)
                                            }
                                            className="w-full p-2 border rounded mb-2"
                                        >
                                            {Object.values(Layer).map((layer) => (
                                                <option key={layer} value={layer}>{layer}</option>
                                            ))}
                                        </select>
                                    ) : (
                                        calculation.layer
                                    )}
                                </td>
                                <td className="py-2 px-4 border-b text-center">
                                    {isEditing ? (
                                        <select
                                            value={calculation.remark}
                                            onChange={(e) =>
                                                handleValueChange(calculation.calculationId!, 'remark', e.target.value)
                                            }
                                            className="w-full p-2 border rounded"
                                        >
                                            {Object.values(Remark).map((remark) => (
                                                <option key={remark} value={remark}>{remark}</option>
                                            ))}
                                        </select>
                                    ) : (
                                        calculation.remark
                                    )}
                                </td>
                                <td className="py-2 px-4 border-b text-center">
                                    {isEditing ? (
                                        <input
                                            type="number"
                                            value={calculation.valuePer8Hours}
                                            onChange={(e) =>
                                                handleValueChange(calculation.calculationId!, 'valuePer8Hours', parseFloat(e.currentTarget.value))
                                            }
                                            className="w-full p-2 border rounded mb-2"
                                        />
                                    ) : (
                                        calculation.valuePer8Hours
                                    )}
                                </td>
                                <td className="py-2 px-4 border-b text-center">
                                    {calculation.valuePerHour}
                                </td>
                                <td className="py-2 px-4 border-b text-center">
                                    {isEditing ? (
                                        <select
                                            value={calculation.targetType}
                                            onChange={(e) =>
                                                handleValueChange(calculation.calculationId!, 'targetType', e.currentTarget.value )
                                            }
                                            className="w-full p-2 border rounded"
                                        >
                                            {Object.values(TargetType).map((type) => (
                                                <option key={type} value={type}>{type}</option>
                                            ))}
                                        </select>
                                    ) : (
                                        calculation.targetType
                                    )}
                                </td>
                                {(user.role === 'admin' || user.role === 'superadmin') && (
                                    <td className="py-2 px-4 border-b text-center">
                                        <button
                                            onClick={() => handleDeleteCalculation(calculation.calculationId!)}
                                            className="bg-transparent hover:bg-red-500 text-white font-bold py-2 px-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" className="w-6 stroke-black h-6" viewBox="0 0 24 24">
                                                <g id="Trash" data-name="Trash">
                                                    <g>
                                                        <path d="M19.45,4.06H15.27v-.5a1.5,1.5,0,0,0-1.5-1.5H10.23a1.5,1.5,0,0,0-1.5,1.5v.5H4.55a.5.5,0,0,0,0,1h.72l.42,14.45a2.493,2.493,0,0,0,2.5,2.43h7.62a2.493,2.493,0,0,0,2.5-2.43l.42-14.45h.72A.5.5,0,0,0,19.45,4.06Zm-9.72-.5a.5.5,0,0,1,.5-.5h3.54a.5.5,0,0,1,.5.5v.5H9.73Zm7.58,15.92a1.5,1.5,0,0,1-1.5,1.46H8.19a1.5,1.5,0,0,1-1.5-1.46L6.26,5.06H17.74Z" />
                                                        <path d="M8.375,8h0a.5.5,0,0,1,1,0l.25,10a.5.5,0,0,1-1,0Z" />
                                                        <path d="M15.625,8.007a.5.5,0,0,0-1,0h0l-.25,10a.5.5,0,0,0,1,0Z" />
                                                    </g>
                                                </g>
                                            </svg>
                                        </button>
                                    </td>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div></div>
        </div>
    );
};

export default Calculations;