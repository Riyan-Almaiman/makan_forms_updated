import iconPaths from './sidebarIcons';

// Define and export the SidebarItemType
export interface SidebarItemType {
    label: string;
    icon: React.ReactNode;
    component: string;
}

const allSidebarItems: SidebarItemType[] = [
    {
        label: 'Submissions',
        icon: iconPaths.submissionsIcon,
        component: 'Submissions',
    },
    {
        label: 'Users',
        icon: iconPaths.addUserIcon,
        component: 'Users',
    },
    {
        label: 'Settings',
        icon: iconPaths.settingsIcon,
        component: 'Settings',
    },
    {
        label: 'Dashboard',
        icon: iconPaths.exportIcon,
        component: 'Dashboard',
    },
    {
        label: 'Forms',
        icon: iconPaths.formsIcon,
        component: 'Forms',
    },
    {
        label: 'Targets',
        icon: iconPaths.calculationsIcon,
        component: 'Targets',
    },
];

export const sidebarItemsByRole: { [key: string]: string[] } = {
    superadmin: [
        'Dashboard',
        'Submissions',
        'Users',
        'Forms',
        'Targets',
        'Settings',
    ],
    admin: [
        'Dashboard',
        'Users',
        'Targets',
        'Settings',
    ],
    supervisor: [
        'Submissions',

        'Dashboard',
        'Targets',

        //'Users',
        'Settings',
    ],
    editor: [
        'Forms',

        'Targets',
        'Settings',
    ],
};

export const getSidebarItemsForRole = (role: string): SidebarItemType[] => {
    const itemsForRole = sidebarItemsByRole[role as keyof typeof sidebarItemsByRole] || [];
    return itemsForRole.map(itemLabel => 
        allSidebarItems.find(item => item.component === itemLabel)
    ).filter((item): item is SidebarItemType => item !== undefined);
};