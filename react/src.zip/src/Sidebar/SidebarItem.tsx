import { SidebarItemType } from "./sidebarConfig";

interface SidebarItemProps {
    item: SidebarItemType;
    isActive: boolean;
    onItemClick: (component: string) => void;
    toggleSidebar: () => void;
}

const SidebarItem: React.FC<SidebarItemProps> = ({
    item,
    isActive,
    onItemClick,
    toggleSidebar,
}) => {
    const { label, icon, component } = item;
    return (
        <div
            onClick={() => {
                onItemClick(component);
                toggleSidebar();
            }}
            className={`flex hover:bg-[#196A58] items-center px-6 py-4 text-xl font-semibold text-gray-100 ${
                isActive ? 'bg-[#196A58]' : ''
            } rounded-md dark:bg-gray-800 dark:text-green-200 mb-4 cursor-pointer`}
        >
            {icon}
            <span>{label}</span>
        </div>
    );
};

export default SidebarItem;