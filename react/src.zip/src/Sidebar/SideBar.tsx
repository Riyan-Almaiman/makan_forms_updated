import { useEffect, useState } from "react";
import { User } from "../types";
import { getSidebarItemsForRole, SidebarItemType } from "./sidebarConfig";
import SidebarItem from "./SidebarItem";
import iconPaths from "./sidebarIcons";

interface Props {
  user: User | null;
  onNavigate: (component: string) => void;
  onLogout: () => void;
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
}

const SideBar = (props: Props) => {
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const sidebarItems: SidebarItemType[] = props.user?.role 
    ? getSidebarItemsForRole(props.user.role) 
    : [];

  useEffect(() => {
    const firstItem = sidebarItems[0];
    if (firstItem) {
      setActiveItem(firstItem.component);
      props.onNavigate(firstItem.component);
    }
  }, [props.user]);

  return (
    <aside
      style={{ backgroundImage: `url(makanBackgroundDark.png)` }}
      className={`fixed z-30 inset-y-0 left-0 transform ${
        props.isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      } md:translate-x-0 transition-transform duration-300 ease-in-out w-64 h-screen px-6 py-10 overflow-y-auto rounded- bg-base-100 border-r rtl:border-r-0 rtl:border-l dark:bg-gray-900 dark:border-gray-700 flex flex-col justify-between`}
    >
      <div>
        <div className="flex justify-center mb-8">
          <img className="sm:h-10" src="makanLogo.png" alt="" />
        </div>
        <nav>
    {sidebarItems.map((item: SidebarItemType) => (
        <SidebarItem
            key={item.component}
            item={item}
            isActive={activeItem === item.component}
            onItemClick={(component) => {
                setActiveItem(component);
                props.onNavigate(component);
            }}
            toggleSidebar={props.toggleSidebar}
        />
    ))}
</nav>
      </div>
      
      <div className="flex flex-col">
        <hr className="my-8 border-gray-200 dark:border-gray-600" />
        <div className="flex justify-center text-gray-100 items-center px-4 -mx-2 mb-4">
          {iconPaths.userIcon}
          <span className="text-gray-100 text-sm dark:text-white-200">
            {props.user?.name ?? ""}
          </span>
        </div>
        <h1 className="justify-center text-sm text-green-300 flex p-0">
          {props.user?.role?.toUpperCase() ?? ""}
        </h1>

        <button
          onClick={props.onLogout}
          className="mt-4 bg-[#196A58] hover:bg-green-700 py-4 text-gray-100 text-xl font-semibold transition-colors duration-300 transform rounded-md flex items-center justify-center space-x-2"
        >
          {iconPaths.logoutIcon}
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default SideBar;