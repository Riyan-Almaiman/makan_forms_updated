// src/services/dashboardService.ts

import axios from 'axios';

const API_URL = 'http://10.80.20.13/api/dashboard';

export type ProductivityData = {
  date: string;
  products: {
    tds7: {
      layers: {
        [key: string]: {
          expectedProductivity: number;
          actualProductivity: number;
          approvedForms: number

        };
      };
    };
    uvmap: {
      layers: {
        [key: string]: {
          expectedProductivity: number;
          actualProductivity: number;
          approvedForms: number

        };
      };
    };
    cartography: {
      layers: {
        [key: string]: {
          expectedProductivity: number;
          actualProductivity: number;
          approvedForms: number
        };
      };
    };
  };
  supervisorStats: Array<{
    supervisorName: string;
    approved: number;
    rejected: number;
    pending: number;
  }>;
  editors: {
    totalHoursWorked: number;
    averageHoursWorked: number;
  };
  forms: {
    pending: number;
    rejected: number;
    approved: number;
  };
};

export const dashboardService = {
  GetProductivityDashboard: async (date: string): Promise<ProductivityData> => {
    const response = await axios.get<ProductivityData>(`${API_URL}/productivity/${date}`);
    return response.data;
  },
};