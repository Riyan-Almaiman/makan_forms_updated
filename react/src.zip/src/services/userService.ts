// src/services/userService.ts

import axios from 'axios';
import { User } from '../types'; // Assuming you have a types file with your interfaces

const API_URL = 'http://10.80.20.13/api/users'; // Base URL for user endpoints

export const userService = {
    login: async (username: string, password: string): Promise<User> => {
        const response = await axios.post<User>(`${API_URL}/login`, { username, password });
        return response.data;
      },
    
      // Validate user
      validateUser: async (taqniaId: number): Promise<User> => {
        const response = await axios.get<User>(`${API_URL}/validate/${taqniaId}`);
        return response.data;
      },
      // Add this to the userService object in userService.ts

changePassword: async (taqniaId: number, newPassword: string): Promise<void> => {
  await axios.put(`${API_URL}/${taqniaId}/password`, { taqniaId, newPassword });
},
    
      // Get user by username
      getUserByUsername: async (username: string): Promise<User> => {
        const response = await axios.get<User>(`${API_URL}/username/${username}`);
        return response.data;
      }, 
      // Get users by role
  getUsersByRole: async (role: string): Promise<User[]> => {
    const response = await axios.get<User[]>(`${API_URL}/role/${role}`);
    console.log(response.data)
    return response.data;
  },
  // Get all users
  getAllUsers: async (): Promise<User[]> => {
    const response = await axios.get<User[]>(API_URL);
    return response.data;
  },

  // Get user by TaqniaID
  getUserByTaqniaId: async (taqniaId: number): Promise<User> => {
    const response = await axios.get<User>(`${API_URL}/${taqniaId}`);
    return response.data;
  },

  // Create new user
  createUser: async (user: User): Promise<User> => {
    const response = await axios.post<User>(API_URL, user);
    return response.data;
  },

  // Update user
  updateUser: async (taqniaId: number, user: User): Promise<void> => {
    await axios.put(`${API_URL}/${taqniaId}`, user);
  },

  // Delete user
  deleteUser: async (taqniaId: number): Promise<void> => {
    await axios.delete(`${API_URL}/${taqniaId}`);
  }
};