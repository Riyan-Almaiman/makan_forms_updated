// src/services/formService.ts

import axios from 'axios';
import { Form } from '../types'; // Assuming you have a types file with your interfaces

const API_URL = 'http://10.80.20.13/api/forms'; // Base URL for form endpoints

export const formService = {
  // Get all forms
  getAllForms: async (): Promise<Form[]> => {
    const response = await axios.get<Form[]>(API_URL);
    return response.data;
  },

  // Get form by ID
  getFormById: async (id: number): Promise<Form> => {
    const response = await axios.get<Form>(`${API_URL}/${id}`);
    return response.data;
  },

  // Create new form
  CreateOrUpdateForm: async (form: Form): Promise<Form> => {
    const response = await axios.post<Form>(API_URL, form);
    return response.data;
  },

  // Update form
  updateForm: async (id: number, form: Form): Promise<void> => {
    await axios.put(`${API_URL}/${id}`, form);
  },

  // Delete form
  deleteForm: async (id: number): Promise<void> => {
    await axios.delete(`${API_URL}/${id}`);
  },

  // Get forms by user TaqniaID
  getFormsByUserTaqniaId: async (taqniaId: number): Promise<Form[]> => {
    const response = await axios.get<Form[]>(`/api/users/${taqniaId}/forms`);
    return response.data;
  },
  getUserFormByDate: async (taqniaId: number, date: string): Promise<Form | null> => {
    try {
      const response = await axios.get<Form>(`${API_URL}/user/${taqniaId}/date/${date}`);
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error) && error.response?.status === 404) {
        return null;
      } else {
        console.error("Error fetching user form by date:", error);
        throw error;
      }
    }
  },
  

  getSupervisorFormsByDate: async (supervisorTaqniaId: number, date: string): Promise<Form[]> => {
    console.log('fetching supervisor forms')
    console.log(date)
    console.log(supervisorTaqniaId)
    const response = await axios.get<Form[]>(`${API_URL}/supervisor/${supervisorTaqniaId}/date/${date}`);

    const res = response.data;
    console.log(res)
    return res;
  },
  // src/services/formService.ts

getSupervisorPendingForms: async (supervisorTaqniaId: number): Promise<Form[]> => {
  console.log('Fetching pending supervisor forms');
  console.log(supervisorTaqniaId);
  const response = await axios.get<Form[]>(`${API_URL}/supervisor/${supervisorTaqniaId}/pending`);
  const res = response.data;
  console.log('pending forms:')
  console.log(res);
  return res;
},
};