// src/services/calculationService.ts

import axios from 'axios';
import { Calculation } from '../types';

const API_URL = 'http://10.80.20.13/api/calculations';

export const calculationService = {
  getAllCalculations: async (): Promise<Calculation[]> => {
    const response = await axios.get<Calculation[]>(API_URL);
    console.log(response.data)
    return response.data;
  },

  getCalculationById: async (id: number): Promise<Calculation> => {
    const response = await axios.get<Calculation>(`${API_URL}/${id}`);
    return response.data;
  },

  createCalculation: async (calculation: Calculation): Promise<Calculation> => {
    const response = await axios.post<Calculation>(API_URL, calculation);
    return response.data;
  },

  updateCalculation: async (id: number, calculation: Calculation): Promise<void> => {
    await axios.put(`${API_URL}/${id}`, calculation);
  },

  deleteCalculation: async (id: number): Promise<void> => {
    await axios.delete(`${API_URL}/${id}`);
  }
};