// src/services/approvalService.ts

import axios from 'axios';
import { Approval } from '../types';

const API_URL = 'http://10.80.20.13/api/approvals';

export const approvalService = {
  getAllApprovals: async (): Promise<Approval[]> => {
    const response = await axios.get<Approval[]>(API_URL);
    return response.data;
  },

  getApprovalById: async (id: number): Promise<Approval> => {
    const response = await axios.get<Approval>(`${API_URL}/${id}`);
    return response.data;
  },

  createApproval: async (approval: Approval): Promise<Approval> => {
    const response = await axios.post<Approval>(API_URL, approval);
    return response.data;
  },

  updateApproval: async (id: number, approval: Approval): Promise<void> => {
    await axios.put(`${API_URL}/${id}`, approval);
  },

  deleteApproval: async (id: number): Promise<void> => {
    await axios.delete(`${API_URL}/${id}`);
  },

  getApprovalsBySupervisor: async (taqniaId: string): Promise<Approval[]> => {
    const response = await axios.get<Approval[]>(`${API_URL}/supervisor/${taqniaId}`);
    return response.data;
  },

  getPendingApprovals: async (): Promise<Approval[]> => {
    const response = await axios.get<Approval[]>(`${API_URL}/pending`);
    return response.data;
  }
};