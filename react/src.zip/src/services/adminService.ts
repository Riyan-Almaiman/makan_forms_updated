// src/services/adminService.ts

import axios from 'axios';

const API_URL = 'http://10.80.20.13/api/admin';

export interface AssignSupervisorRequest {
  supervisorTaqniaId: number;
  product: string | null;
  layer: string | null;
}

export interface Supervisor {
  taqniaID: number;
  name: string;
  product: string | null;
  layer: string | null;
}

export const adminService = {
  // Assign product and layer to supervisor
  assignSupervisor: async (request: AssignSupervisorRequest): Promise<string> => {
    const response = await axios.post<string>(`${API_URL}/assign-supervisor`, request);
    return response.data;
  },

  // Get all supervisors with their assignments
  getAllSupervisors: async (): Promise<Supervisor[]> => {
    const response = await axios.get<Supervisor[]>(`${API_URL}/supervisors`);
    return response.data;
  },


};